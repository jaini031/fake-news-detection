"""
Model training script for fake news detection.
Trains Logistic Regression and Naive Bayes classifiers using TF-IDF vectorization.
"""

import pandas as pd
import numpy as np
import pickle
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from preprocessing import TextPreprocessor, create_sample_dataset

class FakeNewsDetector:
    """Fake news detection model trainer and predictor."""
    
    def __init__(self):
        """Initialize the detector with required components."""
        self.preprocessor = TextPreprocessor()
        self.tfidf_vectorizer = TfidfVectorizer(
            max_features=5000,
            stop_words='english',
            ngram_range=(1, 2),
            min_df=2,
            max_df=0.95
        )
        self.logistic_model = None
        self.naive_bayes_model = None
        self.is_trained = False
    
    def load_data(self, data_source=None):
        """
        Load and prepare the dataset.
        
        Args:
            data_source (str): Path to CSV file or None for sample data
            
        Returns:
            tuple: (X, y) where X is text data and y is labels
        """
        if data_source and os.path.exists(data_source):
            # Load from CSV file
            df = pd.read_csv(data_source)
            print(f"Loaded dataset from {data_source}")
            print(f"Dataset shape: {df.shape}")
        else:
            # Use sample data
            print("Using sample dataset for demonstration")
            sample_data = create_sample_dataset()
            df = pd.DataFrame(sample_data)
            print(f"Sample dataset shape: {df.shape}")
        
        # Combine title and text for better feature extraction
        df['combined_text'] = df['title'] + ' ' + df['text']
        
        # Preprocess the text
        print("Preprocessing text data...")
        df['processed_text'] = df['combined_text'].apply(self.preprocessor.preprocess)
        
        # Prepare features and labels
        X = df['processed_text'].values
        y = df['label'].values
        
        # Convert labels to binary (0 for FAKE, 1 for REAL)
        y_binary = np.where(y == 'REAL', 1, 0)
        
        print(f"Features shape: {X.shape}")
        print(f"Labels distribution: {np.bincount(y_binary)}")
        
        return X, y_binary
    
    def train_models(self, X, y):
        """
        Train both Logistic Regression and Naive Bayes models.
        
        Args:
            X (array): Preprocessed text features
            y (array): Binary labels (0 for FAKE, 1 for REAL)
        """
        print("Training models...")
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        print(f"Training set size: {X_train.shape[0]}")
        print(f"Test set size: {X_test.shape[0]}")
        
        # Fit TF-IDF vectorizer on training data
        print("Fitting TF-IDF vectorizer...")
        X_train_tfidf = self.tfidf_vectorizer.fit_transform(X_train)
        X_test_tfidf = self.tfidf_vectorizer.transform(X_test)
        
        print(f"TF-IDF matrix shape: {X_train_tfidf.shape}")
        
        # Train Logistic Regression
        print("Training Logistic Regression model...")
        self.logistic_model = LogisticRegression(
            random_state=42,
            max_iter=1000,
            C=1.0
        )
        self.logistic_model.fit(X_train_tfidf, y_train)
        
        # Train Naive Bayes
        print("Training Naive Bayes model...")
        self.naive_bayes_model = MultinomialNB(alpha=1.0)
        self.naive_bayes_model.fit(X_train_tfidf, y_train)
        
        # Evaluate models
        self.evaluate_models(X_test_tfidf, y_test)
        
        self.is_trained = True
        print("Model training completed!")
    
    def evaluate_models(self, X_test, y_test):
        """
        Evaluate both models and print performance metrics.
        
        Args:
            X_test (array): Test features
            y_test (array): Test labels
        """
        print("\n" + "="*50)
        print("MODEL EVALUATION")
        print("="*50)
        
        # Logistic Regression evaluation
        lr_predictions = self.logistic_model.predict(X_test)
        lr_accuracy = accuracy_score(y_test, lr_predictions)
        
        print(f"\nLogistic Regression Results:")
        print(f"Accuracy: {lr_accuracy:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, lr_predictions, target_names=['FAKE', 'REAL']))
        print("\nConfusion Matrix:")
        print(confusion_matrix(y_test, lr_predictions))
        
        # Naive Bayes evaluation
        nb_predictions = self.naive_bayes_model.predict(X_test)
        nb_accuracy = accuracy_score(y_test, nb_predictions)
        
        print(f"\nNaive Bayes Results:")
        print(f"Accuracy: {nb_accuracy:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, nb_predictions, target_names=['FAKE', 'REAL']))
        print("\nConfusion Matrix:")
        print(confusion_matrix(y_test, nb_predictions))
        
        # Choose the best model based on accuracy
        if lr_accuracy >= nb_accuracy:
            self.best_model = self.logistic_model
            self.best_model_name = "Logistic Regression"
            print(f"\nBest model: Logistic Regression (Accuracy: {lr_accuracy:.4f})")
        else:
            self.best_model = self.naive_bayes_model
            self.best_model_name = "Naive Bayes"
            print(f"\nBest model: Naive Bayes (Accuracy: {nb_accuracy:.4f})")
    
    def save_models(self, model_dir="models"):
        """
        Save the trained models and vectorizer to disk.
        
        Args:
            model_dir (str): Directory to save models
        """
        if not self.is_trained:
            raise ValueError("Models must be trained before saving!")
        
        # Create models directory if it doesn't exist
        os.makedirs(model_dir, exist_ok=True)
        
        # Save TF-IDF vectorizer
        vectorizer_path = os.path.join(model_dir, "tfidf_vectorizer.pkl")
        with open(vectorizer_path, 'wb') as f:
            pickle.dump(self.tfidf_vectorizer, f)
        print(f"TF-IDF vectorizer saved to {vectorizer_path}")
        
        # Save Logistic Regression model
        lr_path = os.path.join(model_dir, "logistic_model.pkl")
        with open(lr_path, 'wb') as f:
            pickle.dump(self.logistic_model, f)
        print(f"Logistic Regression model saved to {lr_path}")
        
        # Save Naive Bayes model
        nb_path = os.path.join(model_dir, "naive_bayes_model.pkl")
        with open(nb_path, 'wb') as f:
            pickle.dump(self.naive_bayes_model, f)
        print(f"Naive Bayes model saved to {nb_path}")
        
        # Save best model
        best_model_path = os.path.join(model_dir, "best_model.pkl")
        with open(best_model_path, 'wb') as f:
            pickle.dump(self.best_model, f)
        print(f"Best model ({self.best_model_name}) saved to {best_model_path}")
        
        # Save model metadata
        metadata = {
            'best_model_name': self.best_model_name,
            'is_trained': self.is_trained,
            'vectorizer_features': self.tfidf_vectorizer.max_features
        }
        
        metadata_path = os.path.join(model_dir, "model_metadata.pkl")
        with open(metadata_path, 'wb') as f:
            pickle.dump(metadata, f)
        print(f"Model metadata saved to {metadata_path}")
    
    def load_models(self, model_dir="models"):
        """
        Load pre-trained models and vectorizer from disk.
        
        Args:
            model_dir (str): Directory containing saved models
        """
        # Load TF-IDF vectorizer
        vectorizer_path = os.path.join(model_dir, "tfidf_vectorizer.pkl")
        with open(vectorizer_path, 'rb') as f:
            self.tfidf_vectorizer = pickle.load(f)
        
        # Load best model
        best_model_path = os.path.join(model_dir, "best_model.pkl")
        with open(best_model_path, 'rb') as f:
            self.best_model = pickle.load(f)
        
        # Load metadata
        metadata_path = os.path.join(model_dir, "model_metadata.pkl")
        with open(metadata_path, 'rb') as f:
            metadata = pickle.load(f)
            self.best_model_name = metadata['best_model_name']
            self.is_trained = metadata['is_trained']
        
        print(f"Models loaded successfully!")
        print(f"Best model: {self.best_model_name}")
    
    def predict(self, text):
        """
        Predict whether the given text is fake or real news.
        
        Args:
            text (str): News text to classify
            
        Returns:
            dict: Prediction result with label and confidence
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions!")
        
        # Preprocess the text
        processed_text = self.preprocessor.preprocess(text)
        
        # Transform using TF-IDF
        text_tfidf = self.tfidf_vectorizer.transform([processed_text])
        
        # Make prediction
        prediction = self.best_model.predict(text_tfidf)[0]
        confidence = self.best_model.predict_proba(text_tfidf)[0].max()
        
        # Convert prediction to label
        label = "REAL" if prediction == 1 else "FAKE"
        
        return {
            'label': label,
            'confidence': confidence,
            'model_used': self.best_model_name
        }


def main():
    """Main function to train and save the models."""
    print("Fake News Detection Model Training")
    print("="*40)
    
    # Initialize detector
    detector = FakeNewsDetector()
    
    # Load data (using sample data for demonstration)
    X, y = detector.load_data()
    
    # Train models
    detector.train_models(X, y)
    
    # Save models
    detector.save_models()
    
    # Test prediction
    print("\n" + "="*50)
    print("TESTING PREDICTION")
    print("="*50)
    
    test_text = "Scientists have discovered a new planet that could support life. The planet is located in the habitable zone of its star and has conditions similar to Earth."
    result = detector.predict(test_text)
    
    print(f"Test text: {test_text}")
    print(f"Prediction: {result['label']}")
    print(f"Confidence: {result['confidence']:.4f}")
    print(f"Model used: {result['model_used']}")


if __name__ == "__main__":
    main()

