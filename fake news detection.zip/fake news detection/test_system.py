"""
Test script for Fake News Detection System.
Tests the preprocessing, model training, and prediction functionality.
"""

import sys
import os
from preprocessing import TextPreprocessor, create_sample_dataset
from train_model import FakeNewsDetector

def test_preprocessing():
    """Test the text preprocessing functionality."""
    print("Testing text preprocessing...")
    
    preprocessor = TextPreprocessor()
    
    test_text = "Breaking: Scientists discover new planet! The discovery was made using advanced telescopes. This is amazing news for astronomy!"
    
    print(f"Original text: {test_text}")
    processed = preprocessor.preprocess(test_text)
    print(f"Processed text: {processed}")
    
    if processed:
        print("✓ Preprocessing test passed")
        return True
    else:
        print("✗ Preprocessing test failed")
        return False

def test_model_training():
    """Test the model training functionality."""
    print("\nTesting model training...")
    
    try:
        detector = FakeNewsDetector()
        
        # Load sample data
        sample_data = create_sample_dataset()
        import pandas as pd
        df = pd.DataFrame(sample_data)
        df['combined_text'] = df['title'] + ' ' + df['text']
        df['processed_text'] = df['combined_text'].apply(detector.preprocessor.preprocess)
        
        X = df['processed_text'].values
        y = df['label'].values
        y_binary = [1 if label == 'REAL' else 0 for label in y]
        
        # Train models
        detector.train_models(X, y_binary)
        
        print("✓ Model training test passed")
        return True
        
    except Exception as e:
        print(f"✗ Model training test failed: {str(e)}")
        return False

def test_prediction():
    """Test the prediction functionality."""
    print("\nTesting prediction...")
    
    try:
        detector = FakeNewsDetector()
        
        # Load sample data and train
        sample_data = create_sample_dataset()
        import pandas as pd
        df = pd.DataFrame(sample_data)
        df['combined_text'] = df['title'] + ' ' + df['text']
        df['processed_text'] = df['combined_text'].apply(detector.preprocessor.preprocess)
        
        X = df['processed_text'].values
        y = df['label'].values
        y_binary = [1 if label == 'REAL' else 0 for label in y]
        
        detector.train_models(X, y_binary)
        
        # Test prediction
        test_text = "Scientists have discovered a new planet that could support life. The planet is located in the habitable zone of its star."
        result = detector.predict(test_text)
        
        print(f"Test text: {test_text}")
        print(f"Prediction: {result['label']}")
        print(f"Confidence: {result['confidence']:.4f}")
        
        if result['label'] in ['FAKE', 'REAL'] and 0 <= result['confidence'] <= 1:
            print("✓ Prediction test passed")
            return True
        else:
            print("✗ Prediction test failed")
            return False
            
    except Exception as e:
        print(f"✗ Prediction test failed: {str(e)}")
        return False

def main():
    """Main test function."""
    print("Fake News Detection System - Test Suite")
    print("=" * 45)
    
    tests = [
        test_preprocessing,
        test_model_training,
        test_prediction
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\n" + "=" * 45)
    print(f"Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✓ All tests passed! The system is working correctly.")
        return True
    else:
        print("✗ Some tests failed. Please check the error messages above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)




