"""
Setup script for Fake News Detection System.
Downloads required NLTK data and provides installation instructions.
"""

import nltk
import os
import sys

def download_nltk_data():
    """Download required NLTK data."""
    print("Downloading required NLTK data...")
    
    try:
        # Download punkt tokenizer
        nltk.download('punkt', quiet=True)
        print("✓ Downloaded punkt tokenizer")
        
        # Download stopwords
        nltk.download('stopwords', quiet=True)
        print("✓ Downloaded stopwords")
        
        print("NLTK data download completed successfully!")
        return True
        
    except Exception as e:
        print(f"Error downloading NLTK data: {str(e)}")
        return False

def check_dependencies():
    """Check if required packages are installed."""
    required_packages = [
        'flask', 'scikit-learn', 'pandas', 'numpy', 'nltk'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package} is installed")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} is missing")
    
    if missing_packages:
        print(f"\nMissing packages: {', '.join(missing_packages)}")
        print("Please install them using: pip install -r requirements.txt")
        return False
    
    return True

def create_directories():
    """Create necessary directories."""
    directories = ['models', 'templates', 'static', 'data']
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"✓ Created directory: {directory}")
        else:
            print(f"✓ Directory exists: {directory}")

def main():
    """Main setup function."""
    print("Fake News Detection System - Setup")
    print("=" * 40)
    
    # Check dependencies
    print("\n1. Checking dependencies...")
    if not check_dependencies():
        print("\nSetup failed: Missing required packages.")
        print("Please run: pip install -r requirements.txt")
        sys.exit(1)
    
    # Create directories
    print("\n2. Creating directories...")
    create_directories()
    
    # Download NLTK data
    print("\n3. Downloading NLTK data...")
    if not download_nltk_data():
        print("\nSetup failed: Could not download NLTK data.")
        sys.exit(1)
    
    print("\n" + "=" * 40)
    print("Setup completed successfully!")
    print("=" * 40)
    print("\nNext steps:")
    print("1. Train the model: python train_model.py")
    print("2. Run the web app: python app.py")
    print("3. Open your browser: http://localhost:5000")
    print("\nFor more information, see README.md")

if __name__ == "__main__":
    main()




