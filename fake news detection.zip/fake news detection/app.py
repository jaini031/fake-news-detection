"""
Flask web application for fake news detection.
Provides a web interface for users to input news text and get predictions.
"""

from flask import Flask, render_template, request, jsonify, flash
import os
import sys
from train_model import FakeNewsDetector

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'fake_news_detection_secret_key_2024'

# Global detector instance
detector = None

def load_model():
    """Load the pre-trained model."""
    global detector
    try:
        detector = FakeNewsDetector()
        detector.load_models()
        print("Model loaded successfully!")
        return True
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        return False

@app.route('/')
def index():
    """Main page with input form."""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Predict if news is fake or real."""
    try:
        # Get input data
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({
                'error': 'No text provided',
                'success': False
            }), 400
        
        text = data['text'].strip()
        if not text:
            return jsonify({
                'error': 'Empty text provided',
                'success': False
            }), 400
        
        # Check if model is loaded
        if detector is None:
            return jsonify({
                'error': 'Model not loaded. Please contact administrator.',
                'success': False
            }), 500
        
        # Make prediction
        result = detector.predict(text)
        
        # Prepare response
        response = {
            'success': True,
            'prediction': result['label'],
            'confidence': round(result['confidence'] * 100, 2),
            'model_used': result['model_used'],
            'text_length': len(text)
        }
        
        return jsonify(response)
        
    except Exception as e:
        print(f"Prediction error: {str(e)}")
        return jsonify({
            'error': f'Prediction failed: {str(e)}',
            'success': False
        }), 500

@app.route('/health')
def health():
    """Health check endpoint."""
    model_status = "loaded" if detector is not None else "not loaded"
    return jsonify({
        'status': 'healthy',
        'model_status': model_status,
        'version': '1.0.0'
    })

@app.route('/about')
def about():
    """About page."""
    return render_template('about.html')

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors."""
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors."""
    return render_template('500.html'), 500

def main():
    """Main function to run the Flask app."""
    print("Starting Fake News Detection Web Application...")
    
    # Load the model
    if not load_model():
        print("Failed to load model. Please train the model first by running:")
        print("python train_model.py")
        sys.exit(1)
    
    # Run the Flask app
    print("Model loaded successfully!")
    print("Starting web server...")
    print("Open your browser and go to: http://localhost:5000")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )

if __name__ == '__main__':
    main()

