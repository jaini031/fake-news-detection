"""
Text preprocessing utilities for fake news detection.
Handles cleaning, stopword removal, and stemming of text data.
"""

import re
import string
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

class TextPreprocessor:
    """Text preprocessing class for fake news detection."""
    
    def __init__(self):
        """Initialize the preprocessor with required components."""
        self.stop_words = set(stopwords.words('english'))
        self.stemmer = PorterStemmer()
        
        # Add custom stopwords specific to news articles
        self.stop_words.update([
            'said', 'says', 'say', 'told', 'tell', 'tells', 'according',
            'news', 'report', 'reports', 'article', 'articles', 'story',
            'stories', 'time', 'times', 'year', 'years', 'day', 'days',
            'week', 'weeks', 'month', 'months', 'today', 'yesterday',
            'tomorrow', 'monday', 'tuesday', 'wednesday', 'thursday',
            'friday', 'saturday', 'sunday', 'january', 'february',
            'march', 'april', 'may', 'june', 'july', 'august',
            'september', 'october', 'november', 'december'
        ])
    
    def clean_text(self, text):
        """
        Clean the input text by removing special characters, URLs, and extra whitespace.
        
        Args:
            text (str): Input text to clean
            
        Returns:
            str: Cleaned text
        """
        if not isinstance(text, str):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', text)
        
        # Remove email addresses
        text = re.sub(r'\S+@\S+', '', text)
        
        # Remove phone numbers
        text = re.sub(r'[\+]?[1-9]?[0-9]{7,15}', '', text)
        
        # Remove special characters and digits
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove leading and trailing whitespace
        text = text.strip()
        
        return text
    
    def remove_stopwords(self, text):
        """
        Remove stopwords from the text.
        
        Args:
            text (str): Input text
            
        Returns:
            str: Text with stopwords removed
        """
        if not isinstance(text, str):
            return ""
        
        # Tokenize the text
        tokens = word_tokenize(text)
        
        # Remove stopwords
        filtered_tokens = [word for word in tokens if word not in self.stop_words]
        
        # Join tokens back to text
        return ' '.join(filtered_tokens)
    
    def stem_text(self, text):
        """
        Apply stemming to the text.
        
        Args:
            text (str): Input text
            
        Returns:
            str: Text with words stemmed
        """
        if not isinstance(text, str):
            return ""
        
        # Tokenize the text
        tokens = word_tokenize(text)
        
        # Apply stemming
        stemmed_tokens = [self.stemmer.stem(word) for word in tokens]
        
        # Join tokens back to text
        return ' '.join(stemmed_tokens)
    
    def preprocess(self, text):
        """
        Complete preprocessing pipeline for text.
        
        Args:
            text (str): Input text to preprocess
            
        Returns:
            str: Preprocessed text
        """
        if not isinstance(text, str):
            return ""
        
        # Apply all preprocessing steps
        text = self.clean_text(text)
        text = self.remove_stopwords(text)
        text = self.stem_text(text)
        
        return text
    
    def preprocess_batch(self, texts):
        """
        Preprocess a batch of texts.
        
        Args:
            texts (list): List of texts to preprocess
            
        Returns:
            list: List of preprocessed texts
        """
        return [self.preprocess(text) for text in texts]


def create_sample_dataset():
    """
    Create a sample dataset for demonstration purposes.
    In a real scenario, you would load this from a CSV file.
    
    Returns:
        list: List of dictionaries containing sample news data
    """
    sample_data = [
        {
            "title": "Scientists Discover New Planet in Solar System",
            "text": "A team of astronomers has discovered a new planet orbiting our sun. The planet, named Kepler-452b, is located in the habitable zone and may have conditions suitable for life. The discovery was made using advanced telescopes and years of observation data.",
            "label": "REAL"
        },
        {
            "title": "Breaking: Aliens Land in Central Park",
            "text": "Multiple eyewitnesses report seeing a massive UFO landing in Central Park this morning. The aliens are reportedly friendly and have brought advanced technology to share with humanity. Government officials are keeping this information secret.",
            "label": "FAKE"
        },
        {
            "title": "New Study Shows Benefits of Regular Exercise",
            "text": "A comprehensive study published in the Journal of Medicine reveals that regular exercise can reduce the risk of heart disease by up to 30%. The research followed over 10,000 participants for five years and found significant health improvements in those who exercised regularly.",
            "label": "REAL"
        },
        {
            "title": "Secret Government Program Controls Weather",
            "text": "Leaked documents reveal that the government has been secretly controlling weather patterns for decades. The program uses advanced technology to create hurricanes, droughts, and other weather events to manipulate global politics and economies.",
            "label": "FAKE"
        },
        {
            "title": "Tech Company Announces Revolutionary AI Breakthrough",
            "text": "A major technology company has announced a breakthrough in artificial intelligence that could revolutionize healthcare. The new AI system can diagnose diseases with 95% accuracy and is expected to be available in hospitals within two years.",
            "label": "REAL"
        },
        {
            "title": "Celebrity Dies in Mysterious Circumstances",
            "text": "A famous celebrity was found dead under mysterious circumstances. Sources close to the investigation reveal that the death was not accidental and may be connected to a larger conspiracy involving powerful individuals in the entertainment industry.",
            "label": "FAKE"
        },
        {
            "title": "Climate Change Report Shows Alarming Trends",
            "text": "The latest climate change report from the United Nations shows that global temperatures are rising faster than previously predicted. The report warns that immediate action is needed to prevent catastrophic environmental damage within the next decade.",
            "label": "REAL"
        },
        {
            "title": "Ancient Civilization Found Under Antarctica",
            "text": "Archaeologists have discovered the remains of an ancient civilization buried under the ice in Antarctica. The civilization appears to be over 10,000 years old and shows evidence of advanced technology that predates known human history.",
            "label": "FAKE"
        },
        {
            "title": "New Vaccine Shows Promise Against Cancer",
            "text": "Clinical trials for a new cancer vaccine have shown promising results. The vaccine targets specific cancer cells and has shown a 60% success rate in early trials. Researchers are optimistic about its potential to revolutionize cancer treatment.",
            "label": "REAL"
        },
        {
            "title": "Time Travel Technology Discovered by Scientists",
            "text": "A group of scientists claims to have discovered the secret to time travel. The technology uses quantum mechanics to manipulate space-time and has been successfully tested in laboratory conditions. The discovery is being kept secret by government agencies.",
            "label": "FAKE"
        }
    ]
    
    return sample_data


if __name__ == "__main__":
    # Test the preprocessor
    preprocessor = TextPreprocessor()
    
    sample_text = "Breaking: Scientists discover new planet! The discovery was made using advanced telescopes. This is amazing news for astronomy!"
    
    print("Original text:")
    print(sample_text)
    print("\nPreprocessed text:")
    print(preprocessor.preprocess(sample_text))

